package com.example.Trainer.DTO;

import lombok.Data;

@Data
public class TrainerRequest {
    private String name;
    private String email;
    private String phone;
    private String expertise;
    private String password;
}


